package com.centime.Repository;
import com.centime.Model.Character;
import org.springframework.data.jpa.repository.JpaRepository;
public interface CharacterRepository  extends JpaRepository<Character, Long>{
}
