package com.centime.Controller;

import com.centime.Model.Character;
import com.centime.Service.CharacterService;
import com.centime.annotation.LogMethodParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
@RestController
@RequestMapping("/api/characters")
public class CharacterController {
    @Autowired
    private CharacterService characterService;

    // Fetch all characters
    @GetMapping
    public List<Character> getAllCharacters() {
        return characterService.getAllCharacters();
    }

    // Fetch character by ID
    @GetMapping("/{id}")
    public Character getCharacterById(@PathVariable Long id) {
        return characterService.getCharacterById(id);
    }

    // Fetch nested character structure
    @GetMapping("/nested")
    public List<Map<String, Object>> getNestedCharacters() {
        return characterService.getNestedCharacters();
    }

    // Populate the database using POST (for testing)
    @PostMapping("/create")
    public void createCharacter(@RequestBody Character character) {
        characterService.createCharacter(character);
    }
}
