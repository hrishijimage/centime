package com.centime.Controller;
import com.centime.Model.NameRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
@RestController
public class ServiceThreeController {
    @PostMapping("/fullname")
    public ResponseEntity<String> getFullName(@RequestBody NameRequest request) {
        // Log the received JSON payload (optional)
        System.out.println("Received NameRequest: " + request);

        // Concatenate name and surname
        String fullName = request.getName() + " " + request.getSurname();

        // Return the full name as the response
        return ResponseEntity.ok(fullName);
    }
}
