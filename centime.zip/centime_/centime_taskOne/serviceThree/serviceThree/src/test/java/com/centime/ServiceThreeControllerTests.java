package com.centime;
import com.centime.Controller.ServiceThreeController;
import org.junit.jupiter.api.Test;


import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;

import org.springframework.http.MediaType;

import org.springframework.test.web.servlet.MockMvc;


import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
@WebMvcTest(ServiceThreeController.class)
class ServiceThreeControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Test
    void testGetFullName_returnsConcatenatedName() throws Exception {
        String jsonRequest = """
                {
                  "name": "hrishi",
                  "surname": "jimage"
                }
                """;

        mockMvc.perform(post("/fullname")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(jsonRequest))
                .andExpect(status().isOk())
                .andExpect(content().string("hrishi jimage"));
    }
}