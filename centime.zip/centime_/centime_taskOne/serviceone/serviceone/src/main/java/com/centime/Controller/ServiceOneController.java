package com.centime.Controller;

import jakarta.validation.Valid;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.centime.Model.NameRequest;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.DefaultUriBuilderFactory;
import org.springframework.web.util.*;

import java.net.URI;
import java.util.UUID;
import java.util.logging.Logger;



@RestController
@RequestMapping("/api")
public class ServiceOneController {

    private static final Logger logger = Logger.getLogger(ServiceOneController.class.getName());

    @Value("${service2.url}")
    private String service2Url;

    @Value("${service3.url}")
    private String service3Url;

    private final RestTemplate restTemplate;

    public ServiceOneController(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    @GetMapping("/status")
    public ResponseEntity<String> getStatus() {
        logger.info("GET /status - Service is up");
        return ResponseEntity.ok("Up");
    }

    @PostMapping("/concat")
    public ResponseEntity<String> concatNames(@RequestBody @Valid NameRequest request) {
        String traceId = UUID.randomUUID().toString();
        logger.info("POST /concat - Trace ID: " + traceId + ", Request: " + request);

        // Call Service 2 (GET)
        HttpHeaders headers = new HttpHeaders();
        headers.set("X-Trace-Id", traceId);
        HttpEntity<Void> entity = new HttpEntity<>(headers);

        ResponseEntity<String> helloResponse = restTemplate.exchange(
                service2Url + "/hello",
                HttpMethod.GET,
                entity,
                String.class
        );

        // Call Service 3 (POST)
        URI service3Uri = UriComponentsBuilder.fromUriString(service3Url)
                .path("/fullname")
                .build()
                .toUri();

        HttpEntity<NameRequest> requestEntity = new HttpEntity<>(request, headers);
        ResponseEntity<String> fullnameResponse = restTemplate.postForEntity(service3Uri, requestEntity, String.class);

        String result = helloResponse.getBody() + " " + fullnameResponse.getBody();
        logger.info("POST /concat - Trace ID: " + traceId + ", Result: " + result);

        return ResponseEntity.ok(result);
    }
}
