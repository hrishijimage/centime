package com.centime.Exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.converter.HttpMessageNotReadableException;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Object> handleValidationExceptions(MethodArgumentNotValidException ex) {
        String traceId = UUID.randomUUID().toString();
        Instant timestamp = Instant.now();

        Map<String, Object> errorBody = new HashMap<>();
        errorBody.put("timestamp", timestamp);
        errorBody.put("traceId", traceId);
        errorBody.put("status", HttpStatus.BAD_REQUEST.value());
        errorBody.put("error", "Validation Failed");

        Map<String, String> fieldErrors = new HashMap<>();
        ex.getBindingResult().getFieldErrors().forEach(error -> {
            fieldErrors.put(error.getField(), error.getDefaultMessage());
        });

        errorBody.put("details", fieldErrors);
        return new ResponseEntity<>(errorBody, HttpStatus.BAD_REQUEST);
    }

    // JSON parsing error
    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<Object> handleInvalidJson(HttpMessageNotReadableException ex) {
        String traceId = UUID.randomUUID().toString();
        Instant timestamp = Instant.now();

        Map<String, Object> errorBody = new HashMap<>();
        errorBody.put("timestamp", timestamp);
        errorBody.put("traceId", traceId);
        errorBody.put("status", HttpStatus.BAD_REQUEST.value());
        errorBody.put("error", "Invalid JSON request");
        errorBody.put("details", ex.getLocalizedMessage());

        return new ResponseEntity<>(errorBody, HttpStatus.BAD_REQUEST);
    }

    // General/unexpected error
    @ExceptionHandler(Exception.class)
    public ResponseEntity<Object> handleAllUncaughtExceptions(Exception ex) {
        String traceId = UUID.randomUUID().toString();
        Instant timestamp = Instant.now();

        Map<String, Object> errorBody = new HashMap<>();
        errorBody.put("timestamp", timestamp);
        errorBody.put("traceId", traceId);
        errorBody.put("status", HttpStatus.INTERNAL_SERVER_ERROR.value());
        errorBody.put("error", "Unexpected error occurred");
        errorBody.put("details", ex.getMessage());

        return new ResponseEntity<>(errorBody, HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
