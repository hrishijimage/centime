package com.centime;

import com.centime.Model.Character;
import com.centime.Repository.CharacterRepository;
import com.centime.Service.CharacterService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class CharacterServiceTest {

    @Mock
    private CharacterRepository characterRepository;

    @InjectMocks
    private CharacterService characterService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }



    @Test
    void testGetNestedCharacters() {
        List<Character> mockData = List.of(
                new Character(1L, "Wizard", "Gray", 0L),
                new Character(2L, "Mage", "Blue", 1L),
                new Character(3L, "Specialist wizard", "Purple", 1L),

                new Character(4L, "Priest", "White", 0L),
                new Character(5L, "Cleric", "Silver", 4L),
                new Character(6L, "Druid", "Green", 4L),
                new Character(7L, "Priest of specific mythos", "Gold", 4L),

                new Character(8L, "Warrior", "Red", 0L),
                new Character(9L, "Fighter", "Orange", 8L),
                new Character(10L, "Paladin", "White", 8L),
                new Character(11L, "Ranger", "Brown", 8L),

                new Character(12L, "Rogue", "Black", 0L),
                new Character(13L, "Thief", "Dark Gray", 12L),
                new Character(14L, "Assassin", "Shadow", 13L),
                new Character(15L, "Bard", "Pink", 12L));


        when(characterRepository.findAll()).thenReturn(mockData);

        List<Map<String, Object>> result = characterService.getNestedCharacters();

        assertEquals(4, result.size());

        Map<String, Object> rogue = result.stream()
                .filter(m -> "Rogue".equals(m.get("Name")))
                .findFirst()
                .orElseThrow();

        List<Map<String, Object>> rogueSubs = (List<Map<String, Object>>) rogue.get("Sub Classes");
        assertEquals(2, rogueSubs.size());

        Map<String, Object> thief = rogueSubs.stream()
                .filter(m -> "Thief".equals(m.get("Name")))
                .findFirst()
                .orElseThrow();

        List<Map<String, Object>> thiefSubs = (List<Map<String, Object>>) thief.get("Sub Classes");
        assertEquals(1, thiefSubs.size());
        assertEquals("Assassin", thiefSubs.get(0).get("Name"));

    }
}