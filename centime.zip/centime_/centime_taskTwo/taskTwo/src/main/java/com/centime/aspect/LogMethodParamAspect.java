package com.centime.aspect;

import com.centime.annotation.LogMethodParam;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LogMethodParamAspect {

    @Pointcut("@annotation(com.centime.annotation.LogMethodParam)")
    public void logMethodParam() {}

    @Before("logMethodParam()")
    public void logMethodParams(JoinPoint joinPoint) {
        Object[] args = joinPoint.getArgs();
        System.out.println("Method called with arguments: ");
        for (Object arg : args) {
            System.out.println(arg);
        }
    }
}