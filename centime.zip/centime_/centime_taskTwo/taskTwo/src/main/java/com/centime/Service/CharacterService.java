package com.centime.Service;
import com.centime.Model.Character;
import com.centime.Repository.CharacterRepository;
import com.centime.annotation.LogMethodParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

@Service
public class CharacterService {
    @Autowired
    private CharacterRepository characterRepository;
    @LogMethodParam
    public List<Character> getAllCharacters() {
        return characterRepository.findAll();
    }
    @LogMethodParam
    public Character getCharacterById(Long id) {
        return characterRepository.findById(id).orElse(null);
    }
    @LogMethodParam
    public List<Map<String, Object>> getNestedCharacters() {
        List<Character> characters = characterRepository.findAll();
        Map<Long, Map<String, Object>> lookup = new HashMap<>();
        List<Map<String, Object>> result = new ArrayList<>();

         for (Character character : characters) {
            Map<String, Object> map = new HashMap<>();
            map.put("Name", character.getName());
            map.put("Sub Classes", new ArrayList<>());
            lookup.put(character.getId(), map);
        }

         for (Character character : characters) {
            if (character.getParentId() == 0) {
                result.add(lookup.get(character.getId()));
            } else {
                Map<String, Object> parent = lookup.get(character.getParentId());
                ((List<Map<String, Object>>) parent.get("Sub Classes")).add(lookup.get(character.getId()));
            }
        }

        for (Map<String, Object> map : lookup.values()) {
            List<Map<String, Object>> subClasses = (List<Map<String, Object>>) map.get("Sub Classes");
            if (subClasses.isEmpty()) {
                map.remove("Sub Classes");  // Remove empty 'Sub Classes' field
            }
        }

        return result;
    }
    @LogMethodParam
    public void createCharacter(Character character) {
        characterRepository.save(character);
    }
}
